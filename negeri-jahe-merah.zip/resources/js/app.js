require('./bootstrap');


$('.cl').click( function(e) {
    $('.collapse').collapse('hide');
});