
<?php $__env->startSection('header'); ?>
    <header page="news">
        <menu>
            <div class="container-fluid g-0">
                <div class="row g-0">
                    <div class="col-lg-4"></div>
                    <div class="col-lg-6">
                        <div class="menu__wrapper">
                            <?php echo $__env->make('components/presentational/menu/index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    </div>
                    <div class="col-lg-2"></div>
                </div>
            </div>
        </menu>
    </header>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>
    <main page="news">
        <section class="section__first">
            <div class="container-fluid g-0">
                <div class="row g-0">
                    <div class="col-12">
                        <div class="header__sec1">
                            <h2 class="p-white">Latest News</h2>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="wrapper">
                            <div class="container-fluid g-0">
                                <div class="row g-0">
                                    <div class="col-12">
                                        <div class="latestNews__item">
                                            <div class="latestNews__item-img first-item">
                                                <img src="https://source.unsplash.com/random/500x501" width="100%" height="100%"/>
                                            </div>
                                            <div class="latestNews__item-title">
                                                <h4 class="first-title-item">Opening Tour Ginger Walk On December 2022</h4>
                                                <a href="" class="btn-read-more">READ MORE ></a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-12 col-lg-4">
                                        <div class="latestNews__item">
                                            <div class="latestNews__item-img">
                                                <img src="https://source.unsplash.com/random/500x501" width="100%" height="100%"/>
                                            </div>
                                            <div class="latestNews__item-title">
                                                <h4>Opening Tour Ginger Walk On December 2022</h4>
                                                <a href="" class="btn-read-more">READ MORE ></a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-12 col-lg-4">
                                        <div class="latestNews__item">
                                            <div class="latestNews__item-img">
                                                <img src="https://source.unsplash.com/random/500x501" width="100%" height="100%"/>
                                            </div>
                                            <div class="latestNews__item-title">
                                                <h4>Opening Tour Ginger  2022</h4>
                                                <a href="" class="btn-read-more">READ MORE ></a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-12 col-lg-4">
                                        <div class="latestNews__item">
                                            <div class="latestNews__item-img">
                                                <img src="https://source.unsplash.com/random/500x501" width="100%" height="100%"/>
                                            </div>
                                            <div class="latestNews__item-title">
                                                <h4>Opening Tour Ginger Walk On December 2022</h4>
                                                <a href="" class="btn-read-more">READ MORE ></a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-12 col-lg-4">
                                        <div class="latestNews__item">
                                            <div class="latestNews__item-img">
                                                <img src="https://source.unsplash.com/random/500x501" width="100%" height="100%"/>
                                            </div>
                                            <div class="latestNews__item-title">
                                                <h4>Opening Tour Ginger </h4>
                                                <a href="" class="btn-read-more">READ MORE ></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function (params) {
            $('.slider-profile').slick({
                dots: false,
                arrows: false,
                slidesToShow: 3,
                slidesToScroll: 1,
            });
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('components/layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ghass\Documents\Progamming\Work\negeri-jahe-merah\resources\views/web/news/latest-news.blade.php ENDPATH**/ ?>